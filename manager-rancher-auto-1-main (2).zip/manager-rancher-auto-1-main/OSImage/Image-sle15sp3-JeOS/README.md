# Kiwi image profile for QCOW2 format

This repository contains sources that can be used with SUSE Manager to build images that are not the default salt-boot.  This example is a .qcow2 output, and has been tested for use in SUSE Manager as a build profile with both SLES 15 SP3 and SLES 15 SP4 repositories.
In the SUSE Manager Images Profile, this is the URL you should use for this:


https://github.com/dvosburg/manager-rancher-auto-1#main:OSImage/Image-sle15sp3-JeOS
